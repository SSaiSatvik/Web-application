# ASSIGNMENT

## PART 1

* Initially we get a page for login/registeration.We can choose any.
* In login only username-admin and password-admin will work.
* In case of registeration,we are directed to initail page where we can login.
* After login we are directed to profile page.
* There is a nav bar with 3 options(1 options 2 selctions) directing to 4 respective pages.
